document.getElementById("login-form").addEventListener("submit", function(event){
    event.preventDefault();
    // Add your login logic here
  });